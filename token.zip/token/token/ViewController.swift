//
//  ViewController.swift
//  token
//
//  Created by admin on 23/02/2018.
//  Copyright © 2018 mmh. All rights reserved.
//

import UIKit
//import CommonCrypto

class ViewController: UIViewController {

    @IBOutlet weak var mMDString: UITextView!
    @IBOutlet weak var mMD5String: UILabel!
    @IBOutlet var getMD5: [UIView]!
    @IBAction func actMD5(_ sender: Any) {
        var strPhone = md5( inputString:"008613029214562")
        var strContent = md5( inputString:"3333")
        var strSign = "HTw_SMg_01!znb"

        var strAll = md5( inputString: strPhone!+strContent!+strSign )

        mMD5String.text = strAll
        mMDString.text = strAll
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func md5( inputString: String ) -> String! {
        let str = inputString.cString(using: String.Encoding.utf8)
        let strLen = CUnsignedInt(inputString.lengthOfBytes(using: String.Encoding.utf8))
        let digestLength = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLength)
        
        CC_MD5(str!, strLen, result)
        
        let hash = NSMutableString()
        
        for i in 0..<digestLength {
            hash.appendFormat("%02x", result[i])
        }
        
        result.deinitialize()
        
        return String(format: hash as String)
    }
}

